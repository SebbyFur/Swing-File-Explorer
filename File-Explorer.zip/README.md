Small file explorer written with Swing and FX in Java.

Bonjour ! Voici mon petit explorateur de fichier �crit en Swing et en FX. Il utilise la s�rialisation pour permettre la communication entre les fen�tres.

Cr�� par DIOT S�bastien.

Lancement du projet (Swing et FX):
java --module-path {chemin vers les libraires FX} --add-modules javafx.controls,javafx.fxml -cp cls Main

Lancement du projet (FX):
java --module-path {chemin vers les libraires FX} --add-modules javafx.controls,javafx.fxml -cp cls mainfx.MainFX

Lancement du projet (Swing):
java -cp cls mainswing.MainSwing