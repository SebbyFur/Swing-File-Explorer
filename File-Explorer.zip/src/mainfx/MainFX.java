/**
* Classe MainFX, classe principale pour l'interface graphique en FX.
* @author DIOT Sébastien
* @version 10/05/2021
*/

package mainfx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainFX extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Explorateur de fichiers FX");
        Parent root = FXMLLoader.load(getClass().getResource("FXMLMainFX.fxml"));
        primaryStage.setScene(new Scene(root, 300, 275));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
